﻿using System;

namespace SquareTest
{
	class Program
	{
		private static readonly int[,] _dirs = new int[,] {{0, 1}, {1, 0}, {0, -1}, {-1, 0}};

		static void Main(string[] args)
		{
			//FillSquare(5);
		}

		private static void FillSquare(int n)
		{
			int[,] array = new int[n,n];
			Position pos = new Position(0,0);
			int curNumber = 1;
			int dirInd = 0;
			for (;;)
			{
				array[pos.I, pos.J] = curNumber;

				curNumber++;
				if (curNumber > n * n)
					break;

				Position nextPos = pos.Move(_dirs[dirInd, 0], _dirs[dirInd, 1]);
				if (nextPos.I >= 0 && nextPos.I < n && nextPos.J >= 0 && nextPos.J < n && array[nextPos.I, nextPos.J] == 0)
				{
					pos = nextPos;
				}
				else
				{
					dirInd = (dirInd + 1)%4;
					pos = pos.Move(_dirs[dirInd, 0], _dirs[dirInd, 1]);
				}				
			}

			WriteArray(array, n);
		}

		private static void WriteArray(int[,] array, int n)
		{
			for (int i = 0; i < n; i++)
			{
				string line = string.Empty;
				for (int j = 0; j < n; j++)
				{
					line += array[i, j].ToString().PadLeft(4);
				}
				Console.WriteLine(line);
			}
		}

		private class Position
		{
			public int I { get; set; }
			public int J { get; set; }

			public Position(int i, int j)
			{
				I = i;
				J = j;
			}

			public Position Move(int i, int j)
			{
				return new Position(I + i, J + j);
			}
		}


	}
}
